export default {
  primary: "#009BBE",
  secondary: "#8EC7DB",
  lightcolor: "lightgrey",
  dark: "#3B6E91",
  other1: "#B6DCFD",
  other2: "#93C2FD",
};
