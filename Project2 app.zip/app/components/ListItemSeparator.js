import React from "react";
import { View } from "react-native";

function ListItemSeparator(props) {
  return (
    <View style={{ width: "100%", height: 1, backgroundColor: "#F0F8FF" }} />
  );
}

export default ListItemSeparator;
